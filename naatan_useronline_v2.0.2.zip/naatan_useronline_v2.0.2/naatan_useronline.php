<?php

/*
Plugin Name: Naatan.com Useronline
Plugin URI: http://www.naatan.com/?page_id=58
Description: Adds A Useronline Feature To WordPress featuring user names and search bot detection. Supports widgets and comes with configuration page.
Version: 2.0.2
Author: Nathan
Author URI: http://www.naatan.com/
*/

// Check if option array exists
$settings= get_option('naatan_useronline');
if (!is_array($settings)) {
	$settings = array('timeout'=>'300', 'linknames'=>'y', 'showbots'=>'y');
	add_option('naatan_useronline',$settings);
}

// Check if user has Sidebar Widgets installed
$plugins = get_settings('active_plugins');
$options = get_option('widget_naatan_useronline');
if ( !is_array($options)) {
	$options = array('title'=>'Users Online', 'template'=>"	<ul>
	There are currently <b>%useronlinecount%</b> users online.<br>
	%namedbits% <i><b>%guestonlinecount%</b> Guest(s), <b>%botonlinecount%</b> Bot(s)</i>
	</ul>");
	add_option('widget_naatan_useronline',$options);
}

// ## INITIATE BASE SCRIPT ##
naatan_check_table();
$ac_userip = naatan_get_IP();

// Remove timed out visitors
$isunder = time() - $settings['timeout'];
$wpdb->query("DELETE FROM naatan_useronline WHERE ac_time<'$isunder'");
unset($isunder);

// List of Bots to check
$botlist = array(
	"AbachoBOT",
	"Acoon",
	"AESOP_com_SpiderMa",
	"ah-ha.com crawle",
	"alexa",
	"Almaden",
	"appie",
	"Arachnoidea",
	"ArchitextSpider",
	"Ask Jeeves",
	"Atomz",
	"crawler",
	"Cyveillance",
	"DeepIndex",
	"DTSearch",
	"ESISmartSpider",
	"EZResu",
	"FAST",
	"FAST-WebCrawler",
	"Fido",
	"Firefly",
	"Fluffy the spider",
	"froogle",
	"Gigabot",
	"girafabot",
	"Girafa.com",
	"Googlebot",
	"Gulliver",
	"Gulper",
	"HenryTheMiragoRobot",
	"ia_archiver",
	"Indy Library",
	"InfoSeek",
	"inktomi",
	"KIT-Fireball/2.0",
	"LinkWalker",
	"LNSpiderguy",
	"looksmart",
	"Lycos_Spider_(T-Rex)",
	"MantraAgent",
	"MarkWatch",
	"MSN",
	"NameProtect",
	"NationalDirectory",
	"NationalDirectory-SuperSpide",
	"Nazilla",
	"Openbot",
	"Openfind piranha,Shark",
	"rabaz",
	"Robozilla",
	"Scooter",
	"Scrubby",
	"Slurp",
	"Slurp.so/1.0",
	"Slurp/2.0j",
	"Slurp/2.0 ",
	"Slurp/3.0",
	"Spade",
	"Tarantula",
	"TECNOSEEK",
	"Teoma",
	"Teoma_agent1",
	"Teradex Mapper",
	"Tracerlock",
	"UK Searcher Spider",
	"URL_Spider_SQL",
	"W3C_Validator",
	"WDG_Validator",
	"WebBug",
	"WebCrawler",
	"WebFindBot",
	"Winona",
	"www.galaxy.com",
	"Zealbot",
	"ZyBorg
");

// Check if users has visited before with same ip, if not check if visitor has cookies set, if not user is unnamed (cookies are set when visitor comments on your site)
if ($cmnt = $wpdb->get_row("SELECT * FROM $wpdb->comments WHERE comment_author_IP='$ac_userip' LIMIT 1")) {
	$ac_name = $cmnt->comment_author;
	$ac_contact = $cmnt->comment_author_url;
} elseif ($_COOKIE['wordpressuser_'.COOKIEHASH]) {
	$wpusername = $_COOKIE['wordpressuser_'.COOKIEHASH];
	$wpuser = $wpdb->get_row("SELECT * FROM $wpdb->users WHERE user_login='$wpusername' LIMIT 1");
	$ac_name = $wpuser->user_nicename;
	$ac_contact = $wpuser->user_url;
} elseif ($_COOKIE['comment_author_'.COOKIEHASH]) {
	$ac_name = $_COOKIE['comment_author_'.COOKIEHASH];
	$ac_contact = $_COOKIE['comment_author_url_'.COOKIEHASH];
} elseif ($_COOKIE['comment_author']) {
	$ac_name = $_COOKIE['comment_author'];
	$ac_contact = $_COOKIE['comment_author_url'];
} else {
	foreach($botlist as $bot) {
		if(ereg($bot, $HTTP_USER_AGENT)) {
			$ac_name = $bot;
			$ac_contact = 'bot';
		}
	}
	if ($ac_contact!='bot') $ac_name = 'Guest';
}

// Check for session
$ac = $wpdb->get_row("SELECT * FROM naatan_useronline WHERE ac_ip='$ac_userip' LIMIT 1");

if (!$ac->ac_ip) {
	$wpdb->query("INSERT INTO naatan_useronline (ac_id,ac_ip,ac_name,ac_contact,ac_time) VALUES (NULL,'$ac_userip','$ac_name','$ac_contact','".time()."')");
} else {
	$wpdb->query("UPDATE naatan_useronline SET ac_name='$ac_name',ac_contact='$ac_contact',ac_time='".time()."' WHERE ac_ip='$ac_userip'");
}

// ## FUNCTIONS ##

// ## Check if MySQL table exists ##
function naatan_check_table() {
  global $wpdb;
  if (get_option('naatan_useronline_lastupdate')<'1182830400' OR 
			get_option('naatan_useronline_lastupdate')=='') {
			$wpdb->query("DROP TABLE `naatan_useronline`;");
			add_option('naatan_useronline_lastupdate','1182830400');
	}
  $query = "SHOW tables LIKE 'naatan_useronline';";
  $query2 = "SHOW tables LIKE 'naatan_customnames';";
  $result = $wpdb->query($query);
  $result2 = $wpdb->query($query2);
  if(!$result) {
    // Create table if it doesnt exist yet..
    $query = "
CREATE TABLE `naatan_useronline` (
  `ac_id` int(11) NOT NULL auto_increment,
  `ac_ip` varchar(25) NOT NULL default '',
  `ac_name` varchar(100) NOT NULL default '',
  `ac_contact` varchar(255) NOT NULL default '',
  `ac_time` varchar(20) NOT NULL default '',
  PRIMARY KEY  (`ac_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=0;
    ";
    $wpdb->query($query);
  }
  if(!$result2) {
    // Create table if it doesnt exist yet..
    $query = "
CREATE TABLE `naatan_customnames` (
`id` SMALLINT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
`name` VARCHAR( 50 ) NOT NULL ,
`add_before` VARCHAR( 100 ) NOT NULL ,
`add_after` VARCHAR( 100 ) NOT NULL
) ENGINE = MYISAM ;
    ";
    $wpdb->query($query);
    $wpdb->query("INSERT INTO naatan_customnames VALUES (1, 'Example', '<b><font style=\"color: red;\">', '</font></b>')");
  }
}

// ## Get visitor IP ##
function naatan_get_IP() {
	if (empty($_SERVER["HTTP_X_FORWARDED_FOR"])) {
		$ip_address = $_SERVER["REMOTE_ADDR"];
	} else {
		$ip_address = $_SERVER["HTTP_X_FORWARDED_FOR"];
	}
	if(strpos($ip_address, ',') !== false) {
		$ip_address = explode(',', $ip_address);
		$ip_address = $ip_address[0];
	}
	return $ip_address;
}

// ## Get named bits, this returns a list of the named users ##
function naatan_namedbits() {
	global $wpdb;
	$options = get_option('naatan_useronline');
	if ($acq = $wpdb->get_results("SELECT * FROM naatan_useronline WHERE ac_name!='Guest'")) {
		foreach ($acq as $ac) {
			if ($cn = $wpdb->get_row("SELECT * FROM naatan_customnames WHERE name='$ac->ac_name'")) {
				$ac->ac_name = $cn->add_before . $ac->ac_name . $cn->add_after;
			}
			// Make name linkable if contact details are filled
			if (($options['linknames']=='y') AND (strpos($ac->ac_contact,"http")!==false)) {
				$ac->ac_name = '<a href="'.$ac->ac_contact.'" target="_blank">'.$ac->ac_name.'</a>';
			}
			if ($ac->ac_contact=='bot') {
				if ($options[showbots]=='y') {
					$ac->ac_name = "$ac->ac_name (BOT)";
				} else {
					unset($ac);
				}
			}
			if ($ac->ac_name) $namedbits .= "$ac->ac_name, ";
		}
	}

	return $namedbits;
}

// ## Get number of users online ##
function naatan_useronlinecount() {
	global $wpdb;
	$acq = $wpdb->get_results("SELECT * FROM naatan_useronline", ARRAY_N);
	return count($acq);
}

// ## Get number of named users online ##
function naatan_namedonlinecount() {
	global $wpdb;
	$acq = $wpdb->get_results("SELECT * FROM naatan_useronline WHERE ac_name!='Guest'", ARRAY_N);
	return count($acq);
}

// ## Get number of unnamed users online ##
function naatan_guestonlinecount() {
	global $wpdb;
	$acq = $wpdb->get_results("SELECT * FROM naatan_useronline WHERE ac_name='Guest'", ARRAY_N);
	return count($acq);
}

// ## Get number of bots online ##
function naatan_botonlinecount() {
	global $wpdb;
	$acq = $wpdb->get_results("SELECT * FROM naatan_useronline WHERE ac_contact='bot'", ARRAY_N);
	return count($acq);
}

// ## The Admin Page ##
function naatan_useronline_options() {

	global $wpdb;

	// Save new settings
    if ($_POST['save_settings']) {
		if ($_POST['naatan_useronline-linknames']=='Enable') { $settings['linknames'] = 'y'; } else { $settings['linknames'] = 'n'; }
		if ($_POST['naatan_useronline-showbots']=='Enable') { $settings['showbots'] = 'y'; } else { $settings['showbots'] = 'n'; }
		$settings['timeout'] = $_POST['naatan_useronline-timeout'];
		update_option('naatan_useronline', $settings);
    }
    
    if ($_POST['save_cn_settings']) {
		$name = $_POST['naatan_useronline_customname'];
		$addbefore = $_POST['naatan_useronline_addbefore'];
		$addafter = $_POST['naatan_useronline_addafter'];
		$cnid = $_POST['cnid'];
		if ($_POST['formtype']=='insert') {
			$query = "INSERT INTO naatan_customnames (id,name,add_before,add_after) VALUES (NULL,'$name','$addbefore','$addafter')";
			$wpdb->query($query);
		} elseif ($_POST['formtype']=='update') {
			$query = "UPDATE naatan_customnames SET name='$name',add_before='$addbefore',add_after='$addafter' WHERE id='$cnid'";
			$wpdb->query($query);
		}
    }
    if ($_POST['delete_customname']) {
		if ($nameids = $_POST['customnames']) {
			foreach ($nameids as $id) {
				$query = "DELETE FROM naatan_customnames WHERE id='$id'";
				$wpdb->query($query);
			}
		}
    }
    
    // Get settings
    $settings = get_option('naatan_useronline');
	$timeout = $settings['timeout'];
	$linknames = $settings['linknames'];
	if ($linknames=='y') $checked = 'CHECKED';
	$showbots = $settings['showbots'];
	if ($showbots=='y') $checked2 = 'CHECKED';

	// Output the options Page
	echo '
	
	<div class="wrap">
		<h2>Naatan.com Useronline Options</h2>
		<form name="useronlineForm" method="post" action="'.$_SERVER['REQUEST_URI'].'">
			<fieldset class="options">
				<legend>Settings</legend>
				<blockquote>Timeout: 
				<input type="text" name="naatan_useronline-timeout" size="5" value="'.$timeout.'">
				<em>Enter timeout in seconds to define user as offline (idle time)</em>
				</blockquote>
				<blockquote>Link Names: 
				<input type="checkbox" name="naatan_useronline-linknames" value="Enable" '.$checked.'>
				<em>Should names be linkable?</em>
				</blockquote>
				<blockquote>Show Search Bots: 
				<input type="checkbox" name="naatan_useronline-showbots" value="Enable" '.$checked2.'>
				<em>Should bots be listed in online names?</em>
				</blockquote>
			</fieldset>
			<input type="submit" name="save_settings" value="Save Settings"><br><br>
			<fieldset class="options">
				<legend>Custom Names</legend>
				<table border="0" cellspacing="3" cellpadding="3" width="100%">
					<tr>
						<td><b>ID</b></td>
						<td><b>Custom Name</b></td>
						<td><b>Add Before</b></td>
						<td><b>Add After</b></td>
						<td></td>
					</tr>	
	';
	
	if ($cnq = $wpdb->get_results('SELECT * FROM naatan_customnames ORDER BY id')) {
		foreach ($cnq as $cn) {
			$cn->name = htmlspecialchars($cn->name);
			$cn->add_before = htmlspecialchars($cn->add_before);
			$cn->add_after = htmlspecialchars($cn->add_after);
			if ($class) { unset($class); } else { $class = 'class="alternate"'; }
			echo '
					<tr '.$class.'>
						<td><input type="checkbox" name="customnames[]" id="cn_'.$cn->id.'" value="'.$cn->id.'"> '.$cn->id.'</td>
						<td>'.$cn->name.'</td>
						<td>'.$cn->add_before.'</td>
						<td>'.$cn->add_after.'</td>
						<td><a href="#updateform" onClick="naatanFormUpdate('.$cn->id.',\''.$cn->name.'\',\''.$cn->add_before.'\',\''.$cn->add_after.'\')">Edit</a></td>					
					</tr>
			';
		}
	}
	echo '
				</table>
				<input type="submit" name="delete_customname" value="Delete Selected Names"><br><br>
				<legend>Update/Insertion Form</legend>
				<a name="updateform" title="updateform">
				<table border="0" cellspacing="3" cellpadding="3" width="100%">
					<tr>
					  <td><b>Custom Name:</b> <input type="text" id="naatan_useronline_customname" name="naatan_useronline_customname" size="15"></td>
					  <td><b>Add Before:</b> <input type="text" id="naatan_useronline_addbefore" name="naatan_useronline_addbefore" size="15"></td>
					  <td><b>Add After:</b> <input type="text" id="naatan_useronline_addafter" name="naatan_useronline_addafter" size="15"></td>
					  <td><input type="hidden" name="formtype" value="insert"><input type="hidden" name="cnid" value=""><input type="submit" name="save_cn_settings" value="Add"></td>
					</tr>
				</table>
			</fieldset>

 <script type="text/javascript">
function naatanFormUpdate(id,name,addbefore,addafter) {
     document.useronlineForm.naatan_useronline_customname.value=name;
     document.useronlineForm.naatan_useronline_addbefore.value=addbefore;
     document.useronlineForm.naatan_useronline_addafter.value=addafter;
     document.useronlineForm.save_cn_settings.value="Update";
     document.useronlineForm.cnid.value=id;
     document.useronlineForm.formtype.value="update";
}
</script>
			
		</form>
	</div>
	';

}

// ## Add link to the Admin panel ##
function useronline_add_pages() {
    add_options_page('Useronline Settings', 'Useronline', 8, __FILE__, 'naatan_useronline_options');
}

add_action('admin_menu', 'useronline_add_pages');

// Check if user has Sidebar Widgets installed

// ## CONSTRUCT WIDGET ##

function widget_naatan_useronline_init() {

	if ( !function_exists('register_sidebar_widget') )
	return;

	function widget_naatan_useronline($args) {
		extract($args);
		$options = get_option('widget_naatan_useronline');
		$title = $options['title'];
		$template = $options['template'];
		$template = str_replace("%useronlinecount%",naatan_useronlinecount(),$template);
		$template = str_replace("%namedonlinecount%",naatan_namedonlinecount(),$template);
		$template = str_replace("%guestonlinecount%",naatan_guestonlinecount(),$template);
		$template = str_replace("%botonlinecount%",naatan_botonlinecount(),$template);
		$template = str_replace("%namedbits%",naatan_namedbits(),$template);
		echo $before_widget;
		echo $before_title;
		echo $title;
		echo $after_title;
		echo $template;
		echo $after_widget;
	}

	function widget_naatan_useronline_control() {

		$options = get_option('widget_naatan_useronline');
		$settings = get_option('naatan_useronline');

		if ( $_POST['naatan_useronline-submit'] ) {
			// Remember to sanitize and format use input appropriately.
			$options['title'] = strip_tags(stripslashes($_POST['naatan_useronline-title']));
			$options['template'] = stripslashes($_POST['naatan_useronline-template']);
			update_option('widget_naatan_useronline', $options);
		}

		$title = htmlspecialchars($options['title'], ENT_QUOTES);
		$template = htmlspecialchars($options['template'], ENT_QUOTES);
	
		// Here is our little form segment. Notice that we don't need a
		// complete form. This will be embedded into the existing form.
		echo '<p style="text-align:left;"><label for="naatan_useronline-title">' . __('Title:') . ' <input style="width: 200px;" id="naatan_useronline-title" name="naatan_useronline-title" type="text" value="'.$title.'" /></label></p>';
		echo '<p style="text-align:left;"><label for="naatan_useronline-template">' . __('Template:') . ' <br><textarea cols="50" rows="10" id="naatan_useronline-template" name="naatan_useronline-template"/>'.$template.'</textarea></label></p>';
		echo '<p style="text-align:left; font-size: 7pt;">You can use the following tags:<br>
<b>%useronlinecount%</b> => Returns the number of total online users<br>
<b>%namedonlinecount%</b> => Returns the number of named online users<br>
<b>%guestonlinecount%</b> => Returns the number of unnamed online users<br>
<b>%botonlinecount%</b> => Returns the number of search bots browsing your site<br>
<b>%namedbits%</b> => Returns a list (seperated by comma\'s) of the named online users</p>';
		echo '<input type="hidden" id="naatan_useronline-submit" name="naatan_useronline-submit" value="1" />';
	}

	register_widget_control(array('Useronline', 'widgets'), 'widget_naatan_useronline_control', 400, 350);
	register_sidebar_widget(array('Useronline', 'widgets'), 'widget_naatan_useronline');

}

add_action('widgets_init', 'widget_naatan_useronline_init');

?>